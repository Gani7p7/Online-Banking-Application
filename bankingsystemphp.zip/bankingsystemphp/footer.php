<div class="footer">
<ul>
                   
                   <div class="footer_content">
                   <li><a href="features.php">Features </a></li>
                   <li><a href="contact.php"> Contact</a></li>
                 <li><a href="about.php"> About</a></li>
                   <li><a href="safeonlinebanking.php">Safe Online Banking Tips</a></li>
                   
                   <li style="padding-left:450px; color : white"><b>Copyright &copy; <?php echo date("Y"); ?></b></li>
                   
                   </div>
                   </ul>                    
       
    
    
 </div>
           </div> 
    </body>
</html>
