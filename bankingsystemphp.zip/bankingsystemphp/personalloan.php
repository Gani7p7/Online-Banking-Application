<!DOCTYPE html>
<html>
    <head>
        
        <title>Personal Loan</title>
        
        <link rel="stylesheet" href="newcss.css">
        <style>
            .heading{
    font-weight:bold;
    color:#2E4372;
}
        </style>
       
    </head>
        <?php include 'header.php' ?>
        <div class='content_customer'>
            <h3 style="text-align:center;color:#2E4372;"><u>Personal Loan</u></h3>
           
		   <p>
		  <b>Eligibility</b>
		  <br>
		  <br>  
You are eligible if you are a Salaried individual of good quality corporate, self employedengineer, doctor, architect, chartered accountant, MBA with minimum 2 years standing.
<br>
<br>
<b>Loan Amount</b>
<br>
<br>
Your personal loan limit would be determined by your income and repayment capacity.
<br/>
<br>
<b>Minimum :</b>
<br>
<br>
Rs.24,000/- in metro and urban centres
Rs.10,000/- in rural/semi-urban centres
<br>
<br>
<b>Maximum :</b>
<br>
<br>
12 times Net Monthly Income for salaried individuals and pensioners subject to a ceiling of Rs.10 lacs in all centres
Documents Required
Important documents to be furnished while opening a Personal Loan Account:
For existing bank customers
Passport size photograph
From salaried individuals
Latest salary slip and Form 16
<br>
<br>
<b>Documents Required</b>
<br>
<br>
Important documents to be furnished while opening a Personal Loan Account:
For existing bank customers
Passport size photograph
From salaried individuals
Latest salary slip and Form 16
<br>
<br>
<b>Rate of Interest</b>
<br>
<br>
8. 40% above 2 year MCLR floating, currently 17.70% p.a.

		   </p>
            <div class="contact">
			
			
            </div>
            </div>