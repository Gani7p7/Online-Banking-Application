<html>
    <head></head>
    <body>
        
       <?php echo "<h2 style='color:blue;text-align:center;padding-top:100px;'><b>You don't have javascript enabled in your browser! Please enable it to proceed to the website.</b></h2>"; ?>
    </body>
    </html>