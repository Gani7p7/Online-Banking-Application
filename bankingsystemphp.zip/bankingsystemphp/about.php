<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Contact Us</title>
        
        <link rel="stylesheet" href="newcss.css">
        <style>
            .heading{
    font-weight:bold;
    color:#2E4372;
}
        </style>
       
    </head>
        <?php include 'header.php' ?>
        <div class='content_customer'>
            <h3 style="text-align:center;color:#2E4372;"><u>About Us</u></h3>
            <div style = "position : absolute ; top : 200px ; left : 1120px">
	<img src = images/aboutus.jpg height = 200 width = 320>
	</div>
            <table align="center" width="759" border="0">
        <tr>
          <td width="160" height="287"><img src="images/avatar543 boy.jpg" width="160" height="180" />
<br/>
<br>
<img src="images/avatarboy.jpg" width="160" height="180" />
<br/><br>
<img src="images/avatarboy729.png" width="160" height="180" /></td>
          <td valign="top" width="589"><ul>
            <li><strong>Project Information</strong>:</li>
            <ul>
              <li>This is a simple <strong>Online Banking System Project</strong> . It has been developed by <strong>YAMUNA , XYZ and PQR </strong> using <strong>PHP </strong>&amp; <strong>MySQL.</strong></li>
            </ul><br />
            <li><strong>Student Information:</strong></li>
            <ul>
              <li><strong>Name: </strong>YAMUNA</li>
              
              <li><strong>Roll No : </strong>182VSB7039</li>
              <li><strong>Program: </strong>BCA</li>
              <li><strong>Session: </strong>2021</li>
              <li><strong>Department: </strong>Information Technology</li>
              <li><strong>Institute: </strong>JINDAL COLLEGE FOR WOMEN </li>
              
            </ul>
			<br/>
			<ul>
              <li><strong>Name: </strong>XYZ</li>
              
              <li><strong>Roll No : </strong>0191it121034</li>
              <li><strong>Program: </strong>BCA</li>
              <li><strong>Session: </strong>2021</li>
              <li><strong>Department: </strong>Information Technology</li>
              <li><strong>Institute: </strong>JINDAL COLLEGE FOR WOMEN </li>
              
            </ul>
			
			
			<br/>
			<ul>
              <li><strong>Name: </strong>PQR</li>
              
              <li><strong>Roll No : </strong>0191it121022</li>
              <li><strong>Program: </strong>BCA</li>
              <li><strong>Session: </strong>2021</li>
              <li><strong>Department: </strong>Information Technology</li>
              <li><strong>Institute: </strong>JINDAL COLLEGE FOR WOMEN </li>
              
            </ul>
          </ul></td>
        </tr>
      </table>
            </div>