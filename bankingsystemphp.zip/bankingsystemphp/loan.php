<!DOCTYPE html>
<html>
    <head>
        
        <title>Loan Details</title>
        
        <link rel="stylesheet" href="newcss.css">
        <style>
            .heading{
    font-weight:bold;
    color:#2E4372;
}
        </style>
       
    </head>
        <?php include 'header.php' ?>
        <div class='content_customer'>
            <h3 style="text-align:center;color:#2E4372;"><u>Loan Details</u></h3>
            <div style = "position : absolute ; top : 240px ; left : 830px">
	<img src = images/contact_us2.jpg height = 300 width = 500>
	</div>
            <div class="contact">
			
			<a href = houseloan.php>Housing Loan</a>
			<br>
			<br>
			<a href = educationloan.php>Education Loan</a>
			<br>
			<br>
			<a href = personalloan.php>Personal Loan</a>
			<br><br>
			<a href = carloan.php>Car Loan</a>
			<br><br>
            </div>
            </div>